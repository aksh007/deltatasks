package com.example.deltaapp1;

import java.util.ArrayList;
import java.util.Collections;


import android.os.Bundle;

import android.app.Activity;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

	private Button scramble;
	private TextView view;
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		 
		scramble = (Button)findViewById(R.id.button1);
		
		view = (TextView)findViewById(R.id.textView1);
		Toast.makeText(getApplicationContext(), "Press Button to Scramble Text",Toast.LENGTH_LONG).show();
		
		scramble.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				
				jumble("Hello World!");
			
			
			}
		
			private void jumble(String word) {
				// TODO Auto-generated method stub
				ArrayList<Character>al = new ArrayList<Character>();
				for(int i = 0;i<word.length();i++)
				{
					al.add(word.charAt(i));
				}
				Collections.shuffle(al);
				String result = "";
				for(Character character : al)
				{
					result += character;
				}
			view.setText(result);
		    
			}
		});
		
		
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}
	
	
}
